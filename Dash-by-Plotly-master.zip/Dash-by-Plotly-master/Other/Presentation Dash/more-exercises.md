1. Modify the `app.py` app: add room_type dropdown to the layout and callback function
2. Modify the `app.py` app: return a dbc.Alert() if dff is empty (if len(dff)==0)
