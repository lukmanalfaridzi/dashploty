Plotly Express API: https://plotly.com/python-api-reference/plotly.express.html

Dash Core Components: https://dash.plotly.com/dash-core-components

Dash HTML Components: https://dash.plotly.com/dash-html-components

Full Overview of Dash article: https://medium.datadriveninvestor.com/plotly-dash-everything-you-need-to-know-bc09a5e45395

Introduction to Dash by Plotly: https://medium.com/plotly/introducing-dash-5ecf7191b503

Dash App Gallery: https://dash-gallery.plotly.host/Portal/

******************************************************************************
👉 If you appreciate the education I provide, I would mean a lot to me if you could support my work: 

Patreon: https://www.patreon.com/charmingdata

GitHub: https://github.com/sponsors/Coding-with-Adam

YouTube: https://www.youtube.com/channel/UCqBFsuAz41sqWcFjZkqmJqQ/join
******************************************************************************

To Connect with me:

LinkedIn: https://www.linkedin.com/in/adam-schroeder-17b5a819

Twitter: https://twitter.com/charmingdata

Odysee: https://odysee.com/@charmingdata
