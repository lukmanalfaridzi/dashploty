# Resources:
- Plotly Forum - https://community.plotly.com
- YouTube channel - https://www.youtube.com/charmingdata
- Dash Docs - https://dash.plotly.com/
- Dash Example Index - https://dash-example-index.herokuapp.com/
- Plotly graphs - https://plotly.com/python/
- Plotly Express parameteres - https://plotly.github.io/plotly.py-docs/plotly.express.html
- Dash Bootstrap Components - https://dash-bootstrap-components.opensource.faculty.ai/
