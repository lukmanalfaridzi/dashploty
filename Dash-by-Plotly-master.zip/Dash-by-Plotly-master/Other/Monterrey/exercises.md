1. Take the original `mexico-dash.py` app and add room_type dropdown to the layout and callback function
2. Take the original `mexico-dash.py` app and return a dbc.Alert() if dff is empty (if len(dff)==0)
