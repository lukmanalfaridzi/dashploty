link to supporting docs:
https://drive.google.com/file/d/1HtJcu3ZWsDYEIv8srod16z4jD4HEeHuH/view?usp=sharing
