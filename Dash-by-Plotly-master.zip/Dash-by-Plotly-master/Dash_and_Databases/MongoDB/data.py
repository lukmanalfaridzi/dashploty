db.shelterA.insertMany([
    {
        "owner": "Marv",
        "animal": "cat",
        "breed": "tabi",
        "age": 1,
        "health": "good",
        "neutered": false
    },
    {
        "owner": "Adam",
        "animal": "cat",
        "breed": "longthair",
        "age": 3,
        "health": "great",
        "neutered": false
    },
    {
        "owner": "Jim",
        "animal": "cat",
        "breed": "shorthair",
        "age": 2,
        "health": "average",
        "neutered": true
    },
    {
        "owner": "Sebastian",
        "animal": "dog",
        "breed": "french",
        "age": 5,
        "health": "bad",
        "neutered": true
    },
    {
        "owner": "Sindy",
        "animal": "cat",
        "breed": "sphynx",
        "age": 10,
        "health": "average",
        "neutered": true
    },
    {
        "owner": "Prajat",
        "animal": "dog",
        "breed": "buldog",
        "age": 3,
        "health": "good",
        "neutered": true
    },
    {
        "owner": "Sindy",
        "animal": "cat",
        "breed": "sphynx",
        "age": 10,
        "health": "average",
        "neutered": true
    },
    {
        "owner": "Lyla",
        "animal": "cat",
        "breed": "sphynx",
        "age": 4,
        "health": "good",
        "neutered": false
    },
    {
        "owner": "Sam",
        "animal": "dog",
        "breed": "labrador",
        "age": 4,
        "health": "average",
        "neutered": false
    },
    {
        "owner": "Seba",
        "animal": "cat",
        "breed": "sphynx",
        "age": 10,
        "health": "bad",
        "neutered": true
    }
])
