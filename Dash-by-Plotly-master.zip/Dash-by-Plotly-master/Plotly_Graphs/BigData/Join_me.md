# If you forked it, Support it!
A growing number of viewers are looking for high quality, professional content on Dash, which is hard to find. I am trying to fill that gap.

My goal is to make this a sustainable project for myself and my viewers. This code and videos are time-intensive, so if you appreciate my repository and tutorials and are able support their existence, I would be grateful to you. Become my supporter at: https://www.patreon.com/charmingdata
